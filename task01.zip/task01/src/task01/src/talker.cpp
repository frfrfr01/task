#include "ros/ros.h" 
#include "test/my_property.h" 

int main(int argc, char **argv) 
{ 
    ros::init(argc, argv, "talker"); 
    ros::NodeHandle n; 
    ros::Publisher pub = nh.advertise<test::my_property>("property", 10); 
    ros::Rate loop_rate(1);  
    
    while (ros::ok()) 
    {
        test::my_property msg; 
        msg.name = "Student"; 
        msg.Class = 2023; 
        pub.publish(msg); 
        ROS_INFO("Published: name = %s, class = %d", msg.name.c_str(), msg.Class); 
        loop_rate.sleep(); 
        ros::spinOnce();
    }
          
    return 0; 
    
}