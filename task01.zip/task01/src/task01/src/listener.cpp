#include "ros/ros.h" 
#include "test/my_property.h" 

void callback(const test::my_property::ConstPtr& msg) 
{ 
    ROS_INFO("name: %s", msg->name.c_str()); ROS_INFO("Class: %d", msg->Class); 
}
 
int main(int argc, char **argv) 
{ 
    ros::init(argc, argv, "listener"); 
    ros::NodeHandle n; 
    ros::Subscriber sub = nh.subscribe("property", 1000, callback); 
    ros::spin(); 
 
    return 0; 
}